// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.

#include "pch.h"
#include "PlaceholderType.h"
#include "PlaceholderType.g.cpp"

namespace winrt::Microsoft::Terminal::ShellExtension::implementation
{
}
