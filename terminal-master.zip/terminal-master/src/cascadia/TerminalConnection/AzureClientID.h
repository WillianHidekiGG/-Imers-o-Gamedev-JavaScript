// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.

#pragma once

static constexpr std::wstring_view AzureClientID = L"0";
